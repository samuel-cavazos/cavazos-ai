# Orb Chat UI Template

Standalone orb + bottom chat-input UI extracted from the simplified login shell.

## Files

- `index.html`: markup only
- `orb-chat-ui.css`: visual style
- `orb-chat-ui.js`: orb renderer and minimal chat controller

## Behavior

- Includes orb background shader/ripple interaction.
- Includes center speech overlay and bottom composer UI.
- Does not include auth, passkey, backend chat routes, greeting logic, artifact windows, or model/provider logic.

## Hook your own chat behavior

`orb-chat-ui.js` exposes `window.OrbChatUI`.

```js
window.OrbChatUI.setSubmitHandler(async ({ prompt, setBusy, setReply, clearInput, focusInput }) => {
  setBusy(true);
  try {
    const reply = await myChatRequest(prompt);
    setReply(reply);
    clearInput();
    focusInput();
  } catch (error) {
    setReply(error?.message || "Request failed.", true);
  } finally {
    setBusy(false);
  }
});
```

You can also listen to `window` event `orb-chat-ui:submit` if you prefer event-driven wiring.
